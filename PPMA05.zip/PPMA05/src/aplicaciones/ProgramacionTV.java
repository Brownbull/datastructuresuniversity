package aplicaciones;

import clases.Elemento;
import clases.Programa;
import java.util.Scanner;
import pCola.Pcola;



/**
 * Write a description of class ProgramacionTV here.
 * 
 * @author Nina 
 * @version 2016-1
 */
public class ProgramacionTV
{
    public static void main(String[] args)
    {
        Pcola<Programa> pq = new Pcola();
        int preferencia = 0;
        int selection= 99;
        
        while(selection != 0){
            
            System.out.println("Bienvenido Elige una de las opciones");
            System.out.println("1 - Ingresar Programas");
            System.out.println("2 - Mostrar Lista");
            System.out.println("0 - Salir");
            Scanner sc = new Scanner(System.in);
            selection = sc.nextInt();
            switch(selection){
                case 1: 
                    System.out.println("Seleccionaste Ingresar Programas");
                    System.out.println("Ingresa La Cantidad de Programas");
                    int cantidad = sc.nextInt();
                    
                    for(int i = 1;i<= cantidad; i++){
                        System.out.println("Ingresa el programa de la siguiente forma");
                        System.out.println("Nombre,area,tipo,minutos");
                        System.out.println("EJE: La Casa en la pradera,Terror,Serie,25");
                        sc.nextLine();
                        String informacion = sc.nextLine();
                        System.out.println("Ingrese cantidad de preferencias");
                        preferencia = sc.nextInt();
                        pq.add(new Elemento<>(new Programa(informacion),preferencia));
                    }
                    break;
                case 2: 
                    System.out.println("El orden de programacion deberia ser el siguiente");
                    while(!pq.isEmpty()){
                        System.out.print(pq.remove().toString());
                    }
                    System.out.println("fin==========================================");
                    break;
                case 0: 
                    System.out.println("Adios!");
                    System.exit(0);
            }
            
            
        }
        
        
  
       
        
    }

}
