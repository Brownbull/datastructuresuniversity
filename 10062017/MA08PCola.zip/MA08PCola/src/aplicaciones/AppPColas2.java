package aplicaciones;


/**
 * Write a description of class AppPColas here.
 * 
 * @author Nina
 * @version 2016-1
 */
public class AppPColas2{
    public static void main(String[] args){
//        PCola pq= new PCola();
//        
//        cargarHeap(pq);
//        System.out.prinltn(pq.toString());
//        Elemento e= new Elemento<>(new Persona(11781342,"Elsa","Payo",'F','V',new Fecha(1,3,1975)),3);
//        pq.add(e);
//        System.out.prinltn(pq.toString());
//    }
//    
//    public static void cargarHeap(PCola p){
//      
   }
    
}
