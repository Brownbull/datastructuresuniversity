package pCola;


import clases.Elemento;



/**
 * Write a description of class Pcola here.
 * 
 * @author Nina 
 * @version 2016
 * Hacer la clase ITERABLE
 */
public class Pcola<T>{
    private Elemento<T>[] v;
    private int u;
   
//    public Pcola(){
//         
//    }
//    
//    public void add(Elemento<T> e){
//        
//    }
//    
//    public Elemento<T> remove(){
//        
//    }
//       
//    public boolean isEmpty(){
//       return false;
//    }
//    
//    private void subirHeap(){
//        
//       
//    }
//    
//    public String toString(){
//        StringBuffer s= new StringBuffer();
//        
//        return s.toString();
//    }
//    
//    private void bajarHeap(){
//        boolean ubicado=false;
//        Elemento e;
//        int hijo,i, d;
//        int k=1;
//        
//        while (k<=u/2 && !ubicado){
//            i=2*k;
//            hijo= i;
//            if(i<u) {   //tiene hijo derecho. Elegir entre los dos hijos.
//                d=2*k+1;
//                if(v[i].getPrioridad() > v[d].getPrioridad())
//                   hijo=d;
//            }
//            
//            if(v[k].getPrioridad()>v[hijo].getPrioridad()){
//                e= v[k];
//                v[k]=v[hijo];
//                v[hijo]=e;
//                k=hijo;
//            }
//            else{
//                ubicado=true;
//            }
//        }     
//    }
}
